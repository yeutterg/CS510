
public class Move {
	
	// Constructor for a move for a specific piece
	
	public static int pieceNum; 
	public static char moveId;
	
	public Move(int currentPieceNum, char currentMove) {
		pieceNum = currentPieceNum;
		moveId = currentMove;
	}
	
	public int getPieceNum() {
		return pieceNum;
	}
	
	public char getMove() {
		return moveId;
	}
	
	

}
